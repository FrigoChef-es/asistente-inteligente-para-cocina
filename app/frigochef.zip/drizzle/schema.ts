import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal, date } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscription plans for users (freemium model)
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  plan: mysqlEnum("plan", ["free", "premium"]).default("free").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  recipesGeneratedToday: int("recipesGeneratedToday").default(0).notNull(),
  lastRecipeResetDate: date("lastRecipeResetDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Saved recipes for authenticated users
 */
export const savedRecipes = mysqlTable("savedRecipes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  ingredients: text("ingredients").notNull(), // JSON array
  instructions: text("instructions").notNull(),
  prepTime: int("prepTime"), // in minutes
  difficulty: varchar("difficulty", { length: 50 }), // easy, medium, hard
  calories: int("calories"),
  nutritionInfo: text("nutritionInfo"), // JSON object
  sourceIngredients: text("sourceIngredients"), // JSON array of ingredients that generated this recipe
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SavedRecipe = typeof savedRecipes.$inferSelect;
export type InsertSavedRecipe = typeof savedRecipes.$inferInsert;

/**
 * Common ingredients database for autocomplete
 */
export const commonIngredients = mysqlTable("commonIngredients", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  emoji: varchar("emoji", { length: 10 }).notNull(),
  category: varchar("category", { length: 100 }), // vegetables, fruits, proteins, dairy, etc.
});

export type CommonIngredient = typeof commonIngredients.$inferSelect;
export type InsertCommonIngredient = typeof commonIngredients.$inferInsert;

/**
 * Expiry tracking for premium users
 */
export const expiryTracking = mysqlTable("expiryTracking", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  expiryDate: date("expiryDate").notNull(),
  quantity: varchar("quantity", { length: 100 }), // e.g., "500g", "1 liter"
  category: varchar("category", { length: 100 }),
  alertSent: boolean("alertSent").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExpiryTracking = typeof expiryTracking.$inferSelect;
export type InsertExpiryTracking = typeof expiryTracking.$inferInsert;

/**
 * Weekly meal plans for premium users
 */
export const mealPlans = mysqlTable("mealPlans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  week: date("week").notNull(), // Start date of the week
  servings: int("servings").notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }).notNull(),
  dietaryPreferences: text("dietaryPreferences"), // JSON array
  restrictions: text("restrictions"), // JSON array
  mealData: text("mealData").notNull(), // JSON object with breakfast/lunch/dinner for each day
  shoppingList: text("shoppingList").notNull(), // JSON array with items and quantities
  totalCost: decimal("totalCost", { precision: 10, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = typeof mealPlans.$inferInsert;

/**
 * Recipe generation history for analytics and freemium limits
 */
export const recipeHistory = mysqlTable("recipeHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  ingredients: text("ingredients").notNull(), // JSON array
  recipeTitle: text("recipeTitle"),
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
});

export type RecipeHistory = typeof recipeHistory.$inferSelect;
export type InsertRecipeHistory = typeof recipeHistory.$inferInsert;


/**
 * Cached surprise recipes for performance optimization
 * Stores generated surprise recipes keyed by ingredient hash
 * Expires after 24 hours to ensure freshness
 */
export const cachedSurprises = mysqlTable("cachedSurprises", {
  id: int("id").autoincrement().primaryKey(),
  ingredientHash: varchar("ingredientHash", { length: 64 }).notNull().unique(),
  recipe: text("recipe").notNull(), // JSON serialized Recipe object
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  hitCount: int("hitCount").default(0).notNull(), // Track cache hits for analytics
});

export type CachedSurprise = typeof cachedSurprises.$inferSelect;
export type InsertCachedSurprise = typeof cachedSurprises.$inferInsert;


/**
 * User preferences for personalized recipe recommendations
 */
export const userPreferences = mysqlTable("userPreferences", {
  userId: int("userId").primaryKey(),
  difficultyLevel: varchar("difficultyLevel", { length: 20 }).default("Medio"),
  maxPrepTime: int("maxPrepTime").default(60),
  calorieMin: int("calorieMin").default(0),
  calorieMax: int("calorieMax").default(800),
  dietaryRestrictions: text("dietaryRestrictions"),
  cuisinePreferences: text("cuisinePreferences"),
  avoidIngredients: text("avoidIngredients"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertUserPreference = typeof userPreferences.$inferInsert;
