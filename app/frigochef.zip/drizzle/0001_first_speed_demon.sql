CREATE TABLE `commonIngredients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`emoji` varchar(10) NOT NULL,
	`category` varchar(100),
	CONSTRAINT `commonIngredients_id` PRIMARY KEY(`id`),
	CONSTRAINT `commonIngredients_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `expiryTracking` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`expiryDate` date NOT NULL,
	`quantity` varchar(100),
	`category` varchar(100),
	`alertSent` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `expiryTracking_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mealPlans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`week` date NOT NULL,
	`servings` int NOT NULL,
	`budget` decimal(10,2) NOT NULL,
	`dietaryPreferences` text,
	`restrictions` text,
	`mealData` text NOT NULL,
	`shoppingList` text NOT NULL,
	`totalCost` decimal(10,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mealPlans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `recipeHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`ingredients` text NOT NULL,
	`recipeTitle` text,
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `recipeHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `savedRecipes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`ingredients` text NOT NULL,
	`instructions` text NOT NULL,
	`prepTime` int,
	`difficulty` varchar(50),
	`calories` int,
	`nutritionInfo` text,
	`sourceIngredients` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `savedRecipes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`plan` enum('free','premium') NOT NULL DEFAULT 'free',
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`recipesGeneratedToday` int NOT NULL DEFAULT 0,
	`lastRecipeResetDate` date,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`)
);
