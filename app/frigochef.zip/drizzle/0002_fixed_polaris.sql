CREATE TABLE `cachedSurprises` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ingredientHash` varchar(64) NOT NULL,
	`recipe` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	`hitCount` int NOT NULL DEFAULT 0,
	CONSTRAINT `cachedSurprises_id` PRIMARY KEY(`id`),
	CONSTRAINT `cachedSurprises_ingredientHash_unique` UNIQUE(`ingredientHash`)
);
