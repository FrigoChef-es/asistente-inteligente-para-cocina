CREATE TABLE `userPreferences` (
	`userId` int NOT NULL,
	`difficultyLevel` varchar(20) DEFAULT 'Medio',
	`maxPrepTime` int DEFAULT 60,
	`calorieMin` int DEFAULT 0,
	`calorieMax` int DEFAULT 800,
	`dietaryRestrictions` text,
	`cuisinePreferences` text,
	`avoidIngredients` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userPreferences_userId` PRIMARY KEY(`userId`)
);
