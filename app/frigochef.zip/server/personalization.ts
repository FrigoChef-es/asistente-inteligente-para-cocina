import { getUserPreferences, getUserTasteProfile } from "./db";
import { Recipe } from "./recipes";

export interface PersonalizationContext {
  userId: number;
  preferences: any;
  tasteProfile: any;
}

/**
 * Build personalization context for a user
 */
export async function buildPersonalizationContext(userId: number): Promise<PersonalizationContext> {
  const preferences = await getUserPreferences(userId);
  const tasteProfile = await getUserTasteProfile(userId);

  return {
    userId,
    preferences: preferences || getDefaultPreferences(),
    tasteProfile: tasteProfile || null,
  };
}

/**
 * Get default preferences for new users
 */
function getDefaultPreferences() {
  return {
    difficultyLevel: "Medio",
    maxPrepTime: 60,
    calorieMin: 0,
    calorieMax: 800,
    dietaryRestrictions: [],
    cuisinePreferences: [],
    avoidIngredients: [],
  };
}

/**
 * Generate personalized prompt for surprise recipe
 * Incorporates user preferences and taste history
 */
export function generatePersonalizedPrompt(
  ingredients: string[],
  context: PersonalizationContext
): string {
  const { preferences, tasteProfile } = context;
  
  let prompt = `Generate the BEST recipe with: ${ingredients.join(", ")}.`;

  // Add difficulty constraint
  if (preferences?.difficultyLevel) {
    prompt += ` Difficulty: ${preferences.difficultyLevel}.`;
  }

  // Add prep time constraint
  if (preferences?.maxPrepTime) {
    prompt += ` Max prep time: ${preferences.maxPrepTime} minutes.`;
  }

  // Add calorie range
  if (preferences?.calorieMin && preferences?.calorieMax) {
    prompt += ` Calories: ${preferences.calorieMin}-${preferences.calorieMax}.`;
  }

  // Add dietary restrictions
  if (preferences?.dietaryRestrictions?.length > 0) {
    prompt += ` Dietary: ${preferences.dietaryRestrictions.join(", ")}.`;
  }

  // Add cuisine preferences
  if (preferences?.cuisinePreferences?.length > 0) {
    prompt += ` Prefer: ${preferences.cuisinePreferences.join(", ")}.`;
  }

  // Add ingredients to avoid
  if (preferences?.avoidIngredients?.length > 0) {
    prompt += ` Avoid: ${preferences.avoidIngredients.join(", ")}.`;
  }

  // Add taste history insights
  if (tasteProfile) {
    prompt += ` User likes ${tasteProfile.mostCommonDifficulty} recipes around ${tasteProfile.avgCalories} cal.`;
  }

  prompt += " JSON only.";

  return prompt;
}

/**
 * Score a recipe based on user preferences
 * Higher score = better match for user
 */
export function scoreRecipeForUser(recipe: Recipe, context: PersonalizationContext): number {
  const { preferences, tasteProfile } = context;
  let score = 100;

  // Difficulty match (±20 points)
  if (preferences?.difficultyLevel) {
    if (recipe.difficulty === preferences.difficultyLevel) {
      score += 20;
    } else {
      score -= 10;
    }
  }

  // Prep time match (±15 points)
  if (preferences?.maxPrepTime && recipe.prepTime > preferences.maxPrepTime) {
    score -= 15;
  } else if (recipe.prepTime <= (preferences?.maxPrepTime || 60) * 0.8) {
    score += 10;
  }

  // Calorie range match (±15 points)
  if (preferences?.calorieMin && preferences?.calorieMax) {
    if (recipe.calories >= preferences.calorieMin && recipe.calories <= preferences.calorieMax) {
      score += 15;
    } else if (recipe.calories < preferences.calorieMin || recipe.calories > preferences.calorieMax) {
      score -= 15;
    }
  }

  // Avoid ingredients check (±20 points)
  if (preferences?.avoidIngredients?.length > 0) {
    const hasAvoided = recipe.hasIngredients.some((ing: string) =>
      preferences.avoidIngredients.some((avoid: string) =>
        ing.toLowerCase().includes(avoid.toLowerCase())
      )
    );
    if (hasAvoided) {
      score -= 20;
    }
  }

  // Taste history match (±10 points)
  if (tasteProfile) {
    if (Math.abs(recipe.calories - tasteProfile.avgCalories) < 100) {
      score += 10;
    }
  }

  return Math.max(0, score);
}

/**
 * Rank recipes by user preference
 */
export function rankRecipesByPreference(
  recipes: Recipe[],
  context: PersonalizationContext
): Recipe[] {
  const scored = recipes.map((recipe) => ({
    recipe,
    score: scoreRecipeForUser(recipe, context),
  }));

  return scored.sort((a, b) => b.score - a.score).map((item) => item.recipe);
}
