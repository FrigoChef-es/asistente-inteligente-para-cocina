import { describe, it, expect } from "vitest";
import {
  buildPersonalizationContext,
  generatePersonalizedPrompt,
  scoreRecipeForUser,
  rankRecipesByPreference,
} from "./personalization";
import type { Recipe } from "./recipes";

describe("Personalization - FASE 2", () => {
  const mockContext = {
    userId: 1,
    preferences: {
      difficultyLevel: "Medio",
      maxPrepTime: 45,
      calorieMin: 300,
      calorieMax: 600,
      dietaryRestrictions: ["vegetarian"],
      cuisinePreferences: ["Mediterranean"],
      avoidIngredients: ["nuts"],
    },
    tasteProfile: {
      favoriteRecipeCount: 10,
      avgPrepTime: 35,
      avgCalories: 450,
      mostCommonDifficulty: "Medio",
    },
  };

  const mockRecipes: Recipe[] = [
    {
      title: "Mediterranean Pasta",
      prepTime: 30,
      difficulty: "Medio",
      calories: 480,
      hasIngredients: ["pasta", "tomato", "olive oil"],
      missingIngredients: ["basil"],
      instructions: "Cook pasta, add sauce",
      description: "Delicious pasta",
    },
    {
      title: "Complex Beef Stew",
      prepTime: 120,
      difficulty: "Difícil",
      calories: 650,
      hasIngredients: ["beef", "potato"],
      missingIngredients: ["wine"],
      instructions: "Slow cook",
      description: "Heavy meal",
    },
    {
      title: "Simple Salad",
      prepTime: 10,
      difficulty: "Fácil",
      calories: 200,
      hasIngredients: ["lettuce", "tomato"],
      missingIngredients: ["dressing"],
      instructions: "Mix vegetables",
      description: "Light meal",
    },
  ];

  describe("Personalized prompt generation", () => {
    it("should include user preferences in prompt", () => {
      const prompt = generatePersonalizedPrompt(["tomato", "pasta"], mockContext);

      expect(prompt).toContain("Medio");
      expect(prompt).toContain("45");
      expect(prompt).toContain("300-600");
      expect(prompt).toContain("vegetarian");
    });

    it("should include taste history if available", () => {
      const prompt = generatePersonalizedPrompt(["tomato"], mockContext);

      expect(prompt).toContain("450 cal");
      expect(prompt).toContain("Medio");
    });
  });

  describe("Recipe scoring", () => {
    it("should score recipes based on user preferences", () => {
      const score1 = scoreRecipeForUser(mockRecipes[0], mockContext);
      const score2 = scoreRecipeForUser(mockRecipes[1], mockContext);

      // Mediterranean Pasta should score higher (matches preferences)
      expect(score1).toBeGreaterThan(score2);
    });

    it("should penalize recipes with avoided ingredients", () => {
      const recipeWithNuts: Recipe = {
        ...mockRecipes[0],
        hasIngredients: [...mockRecipes[0].hasIngredients, "nuts"],
      };

      const scoreWithout = scoreRecipeForUser(mockRecipes[0], mockContext);
      const scoreWith = scoreRecipeForUser(recipeWithNuts, mockContext);

      expect(scoreWith).toBeLessThan(scoreWithout);
    });

    it("should prefer recipes matching difficulty level", () => {
      const mediumRecipe = mockRecipes[0]; // Medio
      const hardRecipe = mockRecipes[1]; // Difícil

      const mediumScore = scoreRecipeForUser(mediumRecipe, mockContext);
      const hardScore = scoreRecipeForUser(hardRecipe, mockContext);

      expect(mediumScore).toBeGreaterThan(hardScore);
    });

    it("should prefer recipes within calorie range", () => {
      const inRange = mockRecipes[0]; // 480 cal (within 300-600)
      const outOfRange = mockRecipes[1]; // 650 cal (above 600)

      const inRangeScore = scoreRecipeForUser(inRange, mockContext);
      const outOfRangeScore = scoreRecipeForUser(outOfRange, mockContext);

      expect(inRangeScore).toBeGreaterThan(outOfRangeScore);
    });
  });

  describe("Recipe ranking", () => {
    it("should rank recipes by user preference", () => {
      const ranked = rankRecipesByPreference(mockRecipes, mockContext);

      // Mediterranean Pasta should be first (best match)
      expect(ranked[0].title).toBe("Mediterranean Pasta");
    });

    it("should maintain all recipes in ranking", () => {
      const ranked = rankRecipesByPreference(mockRecipes, mockContext);

      expect(ranked).toHaveLength(mockRecipes.length);
      expect(ranked.map((r) => r.title).sort()).toEqual(
        mockRecipes.map((r) => r.title).sort()
      );
    });
  });

  describe("Personalization context", () => {
    it("should provide default preferences for new users", () => {
      const context = {
        userId: 999,
        preferences: {
          difficultyLevel: "Medio",
          maxPrepTime: 60,
          calorieMin: 0,
          calorieMax: 800,
          dietaryRestrictions: [],
          cuisinePreferences: [],
          avoidIngredients: [],
        },
        tasteProfile: null,
      };

      expect(context.preferences).toBeDefined();
      expect(context.preferences.difficultyLevel).toBe("Medio");
    });
  });
});
