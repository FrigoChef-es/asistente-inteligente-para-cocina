import { invokeLLM } from "./_core/llm";

export interface WeeklyMenuRequest {
  people: number;
  budget: number;
  dietaryPreferences: string[];
  restrictions: string[];
}

export interface DayMenu {
  day: string;
  breakfast: string;
  lunch: string;
  dinner: string;
}

export interface ShoppingListItem {
  name: string;
  quantity: string;
  category: string;
  estimatedCost: number;
}

export interface WeeklyMenuResponse {
  menu: DayMenu[];
  shoppingList: ShoppingListItem[];
  totalEstimatedCost: number;
  notes: string;
}

export async function generateWeeklyMenu(
  request: WeeklyMenuRequest
): Promise<WeeklyMenuResponse> {
  const prompt = `Generate a weekly meal plan in Spanish with the following requirements:
- Number of people: ${request.people}
- Budget: €${request.budget}
- Dietary preferences: ${request.dietaryPreferences.join(", ") || "none"}
- Restrictions: ${request.restrictions.join(", ") || "none"}

Return a JSON object with this exact structure:
{
  "menu": [
    {
      "day": "Lunes",
      "breakfast": "meal name",
      "lunch": "meal name",
      "dinner": "meal name"
    },
    ... (7 days total)
  ],
  "shoppingList": [
    {
      "name": "ingredient name",
      "quantity": "amount",
      "category": "category",
      "estimatedCost": number
    },
    ...
  ],
  "totalEstimatedCost": number,
  "notes": "any additional notes"
}

Make sure:
1. All meals are in Spanish
2. Meals are balanced and nutritious
3. Shopping list is optimized to avoid waste
4. Total cost stays within budget
5. All ingredients are practical and commonly available
6. Return ONLY valid JSON, no other text`;

  try {
    const response = await invokeLLM({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "You are a professional meal planner and nutritionist. Generate weekly meal plans that are balanced, budget-friendly, and respect dietary preferences and restrictions. Always respond with valid JSON only.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      maxTokens: 2000,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from AI");
    }

    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const result = JSON.parse(contentStr) as WeeklyMenuResponse;

    if (!result.menu || !Array.isArray(result.menu) || result.menu.length !== 7) {
      throw new Error("Invalid menu format");
    }

    if (!result.shoppingList || !Array.isArray(result.shoppingList)) {
      throw new Error("Invalid shopping list format");
    }

    return result;
  } catch (error) {
    console.error("[WeeklyMenu] Error generating menu:", error);
    throw new Error("Failed to generate weekly menu. Please try again.");
  }
}
