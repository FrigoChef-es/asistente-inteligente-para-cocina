import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { generateRecipes, generateSurpriseRecipe, generatePersonalizedSurpriseRecipe } from "./recipes";
import { generateWeeklyMenu } from "./weeklyMenu";
import { getCommonIngredients, saveRecipe, getSavedRecipes, deleteRecipe, countSavedRecipes, addExpiryItem, getExpiryItems } from "./db";

export const appRouter = router({
  system: router({
    hello: publicProcedure.query(() => "Hello from tRPC"),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const { COOKIE_NAME } = require("@shared/const");
      const { getSessionCookieOptions } = require("./_core/cookies");
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  ingredients: router({
    getCommon: publicProcedure.query(async () => {
      return await getCommonIngredients();
    }),
  }),

  recipes: router({
    generate: protectedProcedure.input(z.object({
      ingredients: z.array(z.string()).min(1),
      count: z.number().min(1).max(5).default(2),
    })).mutation(async ({ ctx, input }) => {
      const recipes = await generateRecipes(input.ingredients, input.count);
      return recipes;
    }),

    surprise: protectedProcedure.input(z.object({
      ingredients: z.array(z.string()).min(1),
    })).mutation(async ({ ctx, input }) => {
      const recipe = await generateSurpriseRecipe(input.ingredients);
      return recipe;
    }),

    surprisePersonalized: protectedProcedure.input(z.object({
      ingredients: z.array(z.string()).min(1),
    })).mutation(async ({ ctx, input }) => {
      const recipe = await generatePersonalizedSurpriseRecipe(input.ingredients, ctx.user.id);
      return recipe;
    }),

    save: protectedProcedure.input(z.object({
      title: z.string(),
      ingredients: z.array(z.string()),
      instructions: z.string(),
      prepTime: z.number(),
      difficulty: z.enum(["Fácil", "Medio", "Difícil"]),
      calories: z.number(),
      hasIngredients: z.array(z.string()),
      missingIngredients: z.array(z.string()),
    })).mutation(async ({ ctx, input }) => {
      const count = await countSavedRecipes(ctx.user.id);
      const limit = ctx.user.role === "admin" ? Infinity : 10;
      if (count >= limit) {
        throw new Error(`Recipe limit reached (${limit})`);
      }
      await saveRecipe(ctx.user.id, input);
      return { success: true };
    }),

    getSaved: protectedProcedure.query(async ({ ctx }) => {
      return await getSavedRecipes(ctx.user.id);
    }),

    delete: protectedProcedure.input(z.object({
      recipeId: z.number(),
    })).mutation(async ({ ctx, input }) => {
      const success = await deleteRecipe(ctx.user.id, input.recipeId);
      return { success };
    }),

    countSaved: protectedProcedure.query(async ({ ctx }) => {
      return await countSavedRecipes(ctx.user.id);
    }),
  }),

  fridgeScan: router({
    analyze: protectedProcedure.input(z.object({
      imageUrl: z.string().url(),
    })).mutation(async ({ ctx, input }) => {
      const { analyzeFridgeImage } = await import("./fridgeScan");
      return await analyzeFridgeImage(input.imageUrl);
    }),
  }),

  weeklyMenu: router({
    generate: protectedProcedure.input(z.object({
      people: z.number().min(1).max(20),
      budget: z.number().min(10).max(500),
      dietaryPreferences: z.array(z.string()).default([]),
      restrictions: z.array(z.string()).default([]),
    })).mutation(async ({ ctx, input }) => {
      const menu = await generateWeeklyMenu(input);
      return menu;
    }),
  }),

  expiry: router({
    getItems: protectedProcedure.query(async ({ ctx }) => {
      return await getExpiryItems(ctx.user.id);
    }),
    addItem: protectedProcedure.input(z.object({
      productName: z.string(),
      expiryDate: z.string(),
      quantity: z.string().optional(),
      category: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      await addExpiryItem(ctx.user.id, input.productName, new Date(input.expiryDate), input.quantity, input.category);
      return { success: true };
    }),
  }),

  cacheAnalytics: router({
    getStats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Unauthorized");
      }
      const { getCacheStats } = await import("./db");
      return await getCacheStats();
    }),
  }),

  preferences: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const { getUserPreferences } = await import("./db");
      return await getUserPreferences(ctx.user.id);
    }),
    update: protectedProcedure.input(z.object({
      difficultyLevel: z.enum(["Fácil", "Medio", "Difícil"]).optional(),
      maxPrepTime: z.number().min(15).max(180).optional(),
      calorieMin: z.number().min(0).optional(),
      calorieMax: z.number().min(100).optional(),
      dietaryRestrictions: z.array(z.string()).optional(),
      cuisinePreferences: z.array(z.string()).optional(),
      avoidIngredients: z.array(z.string()).optional(),
    })).mutation(async ({ ctx, input }) => {
      const { upsertUserPreferences } = await import("./db");
      await upsertUserPreferences(ctx.user.id, input);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
