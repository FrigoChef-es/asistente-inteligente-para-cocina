import { invokeLLM } from "./_core/llm";
import { z } from "zod";

/**
 * Analyze a fridge image and extract detected ingredients using AI vision
 */
export async function analyzeFridgeImage(imageBase64: string): Promise<string[]> {
  if (!imageBase64) {
    throw new Error("Image is required");
  }

  const prompt = `Analyze this image of a refrigerator and list all the food ingredients you can see.

Return ONLY a JSON array of ingredient names in Spanish, like this:
["Huevos", "Queso", "Tomate", "Pollo"]

Be specific and include quantities if visible (e.g., "3 huevos" or "medio queso").
If you can't identify ingredients clearly, skip them.
Return ONLY the JSON array, no other text.`;

  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "You are a food recognition AI. Analyze images of refrigerators and identify all visible food ingredients. Always respond with valid JSON only.",
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt,
            },
            {
              type: "image_url",
              image_url: {
                url: imageBase64,
              },
            },
          ],
        },
      ],
      maxTokens: 500,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from AI");
    }

    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const ingredients = JSON.parse(contentStr);

    if (!Array.isArray(ingredients)) {
      throw new Error("Invalid response format");
    }

    // Filter and clean ingredient names
    return ingredients
      .filter((ing: any) => typeof ing === "string" && ing.length > 0)
      .map((ing: string) => ing.trim())
      .slice(0, 20); // Limit to 20 ingredients
  } catch (error) {
    console.error("[FridgeScan] Error analyzing image:", error);
    throw new Error("Failed to analyze image. Please try again.");
  }
}
