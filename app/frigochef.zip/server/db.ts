import { eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, commonIngredients, subscriptions, savedRecipes, recipeHistory, expiryTracking, mealPlans, cachedSurprises, userPreferences } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

// Ingredients queries
export async function getCommonIngredients() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get ingredients: database not available");
    return [];
  }

  try {
    return await db.select().from(commonIngredients);
  } catch (error) {
    console.error("[Database] Failed to get common ingredients:", error);
    return [];
  }
}

// Subscription queries
export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get subscription:", error);
    return null;
  }
}

export async function createOrUpdateSubscription(userId: number, plan: "free" | "premium" = "free") {
  const db = await getDb();
  if (!db) return null;

  try {
    const existing = await getUserSubscription(userId);
    if (existing) {
      await db.update(subscriptions).set({ plan }).where(eq(subscriptions.userId, userId));
      return existing;
    }
    await db.insert(subscriptions).values({ userId, plan });
    return await getUserSubscription(userId);
  } catch (error) {
    console.error("[Database] Failed to create/update subscription:", error);
    return null;
  }
}

// Recipe history queries
export async function addRecipeHistory(userId: number | null, ingredients: string[], recipeTitle?: string) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.insert(recipeHistory).values({
      userId,
      ingredients: JSON.stringify(ingredients),
      recipeTitle,
    });
  } catch (error) {
    console.error("[Database] Failed to add recipe history:", error);
  }
}

export async function countRecipesToday(userId: number) {
  const db = await getDb();
  if (!db) return 0;

  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const result = await db.select().from(recipeHistory).where(eq(recipeHistory.userId, userId));
    return result.filter(r => {
      const date = new Date(r.generatedAt);
      date.setHours(0, 0, 0, 0);
      return date.getTime() === today.getTime();
    }).length;
  } catch (error) {
    console.error("[Database] Failed to count recipes today:", error);
    return 0;
  }
}

// Saved recipes queries
export async function getSavedRecipes(userId: number) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db.select().from(savedRecipes).where(eq(savedRecipes.userId, userId));
  } catch (error) {
    console.error("[Database] Failed to get saved recipes:", error);
    return [];
  }
}

export async function saveRecipe(userId: number, recipe: any) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.insert(savedRecipes).values({
      userId,
      title: recipe.title,
      description: recipe.description || "",
      ingredients: JSON.stringify(recipe.ingredients),
      instructions: recipe.instructions,
      prepTime: recipe.prepTime,
      difficulty: recipe.difficulty,
      calories: recipe.calories,
      nutritionInfo: recipe.nutritionInfo ? JSON.stringify(recipe.nutritionInfo) : null,
      sourceIngredients: JSON.stringify(recipe.sourceIngredients || []),
    });
  } catch (error) {
    console.error("[Database] Failed to save recipe:", error);
  }
}

// Expiry tracking queries
export async function addExpiryItem(userId: number, productName: string, expiryDate: Date, quantity?: string, category?: string) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.insert(expiryTracking).values({
      userId,
      productName,
      expiryDate,
      quantity,
      category,
    });
  } catch (error) {
    console.error("[Database] Failed to add expiry item:", error);
  }
}

export async function getExpiryItems(userId: number) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db.select().from(expiryTracking).where(eq(expiryTracking.userId, userId));
  } catch (error) {
    console.error("[Database] Failed to get expiry items:", error);
    return [];
  }
}

// Meal plans queries
export async function saveMealPlan(userId: number, mealPlan: any) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.insert(mealPlans).values({
      userId,
      week: mealPlan.week,
      servings: mealPlan.servings,
      budget: mealPlan.budget,
      dietaryPreferences: JSON.stringify(mealPlan.dietaryPreferences),
      restrictions: JSON.stringify(mealPlan.restrictions),
      mealData: JSON.stringify(mealPlan.mealData),
      shoppingList: JSON.stringify(mealPlan.shoppingList),
      totalCost: mealPlan.totalCost,
    });
  } catch (error) {
    console.error("[Database] Failed to save meal plan:", error);
  }
}

export async function deleteRecipe(userId: number, recipeId: number) {
  const db = await getDb();
  if (!db) return false;

  try {
    const result = await db.delete(savedRecipes).where(
      eq(savedRecipes.userId, userId) && eq(savedRecipes.id, recipeId)
    );
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete recipe:", error);
    return false;
  }
}

export async function countSavedRecipes(userId: number) {
  const db = await getDb();
  if (!db) return 0;

  try {
    const result = await db.select().from(savedRecipes).where(eq(savedRecipes.userId, userId));
    return result.length;
  } catch (error) {
    console.error("[Database] Failed to count saved recipes:", error);
    return 0;
  }
}


// Cached surprise recipes queries
export async function getCachedSurprise(ingredientHash: string) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.select().from(cachedSurprises).where(
      eq(cachedSurprises.ingredientHash, ingredientHash)
    );
    
    if (result.length === 0) return null;
    
    const cached = result[0];
    
    // Check if cache has expired
    if (new Date() > cached.expiresAt) {
      // Delete expired cache
      await db.delete(cachedSurprises).where(
        eq(cachedSurprises.ingredientHash, ingredientHash)
      );
      return null;
    }
    
    // Increment hit count
    await db.update(cachedSurprises)
      .set({ hitCount: cached.hitCount + 1 })
      .where(eq(cachedSurprises.ingredientHash, ingredientHash));
    
    return JSON.parse(cached.recipe);
  } catch (error) {
    console.error("[Database] Failed to get cached surprise:", error);
    return null;
  }
}

export async function saveCachedSurprise(ingredientHash: string, recipe: any) {
  const db = await getDb();
  if (!db) return false;

  try {
    // Cache for 24 hours
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    
    await db.insert(cachedSurprises).values({
      ingredientHash,
      recipe: JSON.stringify(recipe),
      expiresAt,
    }).onDuplicateKeyUpdate({
      set: {
        recipe: JSON.stringify(recipe),
        expiresAt,
        createdAt: new Date(),
      },
    });
    
    return true;
  } catch (error) {
    console.error("[Database] Failed to save cached surprise:", error);
    return false;
  }
}

export async function clearExpiredCache() {
  const db = await getDb();
  if (!db) return 0;

  try {
    await db.delete(cachedSurprises).where(
      sql`expiresAt < NOW()`
    );
    return 0;
  } catch (error) {
    console.error("[Database] Failed to clear expired cache:", error);
    return 0;
  }
}

export async function getCacheStats() {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.select().from(cachedSurprises);
    const totalHits = result.reduce((sum, item) => sum + item.hitCount, 0);
    
    return {
      totalCached: result.length,
      totalHits,
      avgHitsPerRecipe: result.length > 0 ? totalHits / result.length : 0,
    };
  } catch (error) {
    console.error("[Database] Failed to get cache stats:", error);
    return null;
  }
}


// User preferences queries
export async function getUserPreferences(userId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get user preferences:", error);
    return null;
  }
}

export async function upsertUserPreferences(userId: number, prefs: any) {
  const db = await getDb();
  if (!db) return false;

  try {
    const values: any = {
      userId,
      difficultyLevel: prefs.difficultyLevel || "Medio",
      maxPrepTime: prefs.maxPrepTime || 60,
      calorieMin: prefs.calorieMin || 0,
      calorieMax: prefs.calorieMax || 800,
    };

    if (prefs.dietaryRestrictions) {
      values.dietaryRestrictions = JSON.stringify(prefs.dietaryRestrictions);
    }
    if (prefs.cuisinePreferences) {
      values.cuisinePreferences = JSON.stringify(prefs.cuisinePreferences);
    }
    if (prefs.avoidIngredients) {
      values.avoidIngredients = JSON.stringify(prefs.avoidIngredients);
    }

    await db.insert(userPreferences).values(values).onDuplicateKeyUpdate({
      set: values,
    });

    return true;
  } catch (error) {
    console.error("[Database] Failed to upsert user preferences:", error);
    return false;
  }
}

export async function getUserTasteProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    // Get user's saved recipes to analyze taste
    const recipes = await db.select().from(savedRecipes).where(eq(savedRecipes.userId, userId));
    
    if (recipes.length === 0) return null;

    // Analyze common patterns
    const difficulties = recipes.map((r: any) => r.difficulty);
    const prepTimes = recipes.map((r: any) => r.prepTime);
    const caloriesList = recipes.map((r: any) => r.calories);

    return {
      favoriteRecipeCount: recipes.length,
      avgPrepTime: Math.round(prepTimes.reduce((a: number, b: number) => a + b, 0) / prepTimes.length),
      avgCalories: Math.round(caloriesList.reduce((a: number, b: number) => a + b, 0) / caloriesList.length),
      mostCommonDifficulty: difficulties.sort((a: any, b: any) => 
        difficulties.filter((x: any) => x === a).length - difficulties.filter((x: any) => x === b).length
      ).pop(),
    };
  } catch (error) {
    console.error("[Database] Failed to get user taste profile:", error);
    return null;
  }
}
