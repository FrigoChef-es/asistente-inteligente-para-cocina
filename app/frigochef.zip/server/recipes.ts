import { invokeLLM } from "./_core/llm";
import { z } from "zod";
import crypto from "crypto";
import { getCachedSurprise, saveCachedSurprise } from "./db";

export const RecipeSchema = z.object({
  title: z.string(),
  prepTime: z.number(),
  difficulty: z.enum(["Fácil", "Medio", "Difícil"]),
  calories: z.number(),
  hasIngredients: z.array(z.string()),
  missingIngredients: z.array(z.string()),
  instructions: z.string(),
  description: z.string().optional(),
});

export type Recipe = z.infer<typeof RecipeSchema>;

/**
 * Generate a hash of ingredients for caching purposes
 */
function generateIngredientHash(ingredients: string[]): string {
  const sorted = [...ingredients].sort().join("|");
  return crypto.createHash("sha256").update(sorted).digest("hex");
}

/**
 * Fallback recipes for when AI is unavailable
 */
const FALLBACK_RECIPES: Record<string, Recipe> = {
  default: {
    title: "Ensalada Mixta",
    prepTime: 10,
    difficulty: "Fácil",
    calories: 150,
    hasIngredients: [],
    missingIngredients: ["Lechuga", "Tomate", "Cebolla"],
    instructions: "1. Lavar verduras\n2. Cortar en trozos\n3. Mezclar en un bol\n4. Añadir aceite y vinagre\n5. Servir",
    description: "Una ensalada fresca y ligera",
  },
  protein: {
    title: "Pollo a la Plancha",
    prepTime: 20,
    difficulty: "Fácil",
    calories: 350,
    hasIngredients: ["Pollo"],
    missingIngredients: ["Sal", "Pimienta", "Aceite"],
    instructions: "1. Sazonar el pollo\n2. Calentar la plancha\n3. Cocinar 8-10 min por lado\n4. Servir caliente",
    description: "Proteína magra y deliciosa",
  },
};

/**
 * Get a fallback recipe based on available ingredients
 */
function getFallbackRecipe(ingredients: string[]): Recipe {
  // If we have protein ingredients, suggest protein recipe
  const proteinKeywords = ["pollo", "carne", "pescado", "huevo", "tofu"];
  const hasProtein = ingredients.some(ing =>
    proteinKeywords.some(keyword => ing.toLowerCase().includes(keyword))
  );

  const fallback = hasProtein ? FALLBACK_RECIPES.protein : FALLBACK_RECIPES.default;
  return {
    ...fallback,
    hasIngredients: ingredients.filter(ing =>
      fallback.hasIngredients.some(fav => fav.toLowerCase() === ing.toLowerCase())
    ),
  };
}

/**
 * Generate recipes based on available ingredients using AI
 */
export async function generateRecipes(ingredients: string[], count: number = 2): Promise<Recipe[]> {
  if (ingredients.length === 0) {
    throw new Error("At least one ingredient is required");
  }

  const ingredientsList = ingredients.join(", ");
  // Optimized prompt: concise and focused (45 tokens vs 127)
  const prompt = `Generate ${count} recipes with: ${ingredientsList}. JSON only.`;

  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "Chef AI. Generate recipes as JSON array only. Each: {title, prepTime (15-60), difficulty (Fácil/Medio/Difícil), calories, hasIngredients, missingIngredients, instructions, description}",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      maxTokens: 1500, // Reduced from 2000
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from AI");
    }

    // Parse the JSON response
    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const recipes = JSON.parse(contentStr);

    // Validate each recipe
    if (!Array.isArray(recipes)) {
      throw new Error("Invalid response format");
    }

    return recipes.map((recipe: any) => RecipeSchema.parse(recipe));
  } catch (error) {
    console.error("[RecipeGenerator] Error generating recipes:", error);
    throw new Error("Failed to generate recipes. Please try again.");
  }
}

/**
 * Generate a single "surprise me" recipe with caching and timeout
 * - Uses cache for repeated ingredient combinations
 * - Falls back to predefined recipe if AI fails
 * - Has timeout to prevent long waits
 */
export async function generateSurpriseRecipe(ingredients: string[]): Promise<Recipe> {
  if (ingredients.length === 0) {
    throw new Error("At least one ingredient is required");
  }

  const ingredientHash = generateIngredientHash(ingredients);

  // Check cache first
  try {
    const cached = await getCachedSurprise(ingredientHash);
    if (cached) {
      console.log("[RecipeGenerator] Cache hit for ingredients:", ingredients);
      return cached;
    }
  } catch (error) {
    console.warn("[RecipeGenerator] Cache lookup failed:", error);
  }

  // Try to generate with AI, with timeout
  try {
    const recipe = await Promise.race([
      generateSurpriseRecipeAI(ingredients),
      new Promise<Recipe>((_, reject) =>
        setTimeout(() => reject(new Error("AI timeout")), 3000)
      ),
    ]);

    // Save to cache
    try {
      await saveCachedSurprise(ingredientHash, recipe);
    } catch (error) {
      console.warn("[RecipeGenerator] Failed to cache recipe:", error);
    }

    return recipe;
  } catch (error) {
    console.warn("[RecipeGenerator] AI generation failed, using fallback:", error);
    // Return fallback recipe
    return getFallbackRecipe(ingredients);
  }
}

/**
 * Generate personalized surprise recipe based on user preferences
 */
export async function generatePersonalizedSurpriseRecipe(
  ingredients: string[],
  userId: number
): Promise<Recipe> {
  if (ingredients.length === 0) {
    throw new Error("At least one ingredient is required");
  }

  const { buildPersonalizationContext, generatePersonalizedPrompt } = await import("./personalization");
  const context = await buildPersonalizationContext(userId);
  const ingredientHash = generateIngredientHash(ingredients);

  // Check cache first
  try {
    const cached = await getCachedSurprise(ingredientHash);
    if (cached) {
      console.log("[RecipeGenerator] Cache hit for personalized recipe:", ingredients);
      return cached;
    }
  } catch (error) {
    console.warn("[RecipeGenerator] Cache lookup failed:", error);
  }

  // Try to generate with AI, with timeout
  try {
    const prompt = generatePersonalizedPrompt(ingredients, context);
    const recipe = await Promise.race([
      generateSurpriseRecipeAIWithPrompt(prompt),
      new Promise<Recipe>((_, reject) =>
        setTimeout(() => reject(new Error("AI timeout")), 3000)
      ),
    ]);

    // Save to cache
    try {
      await saveCachedSurprise(ingredientHash, recipe);
    } catch (error) {
      console.warn("[RecipeGenerator] Failed to cache recipe:", error);
    }

    return recipe;
  } catch (error) {
    console.warn("[RecipeGenerator] Personalized generation failed, using fallback:", error);
    return getFallbackRecipe(ingredients);
  }
}

/**
 * Internal function: Generate surprise recipe via AI with custom prompt
 */
async function generateSurpriseRecipeAIWithPrompt(prompt: string): Promise<Recipe> {
  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "Chef AI. Best recipe as JSON: {title, prepTime (15-60), difficulty (Fácil/Medio/Difícil), calories, hasIngredients, missingIngredients, instructions, description}",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      maxTokens: 800,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from AI");
    }

    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const recipe = JSON.parse(contentStr);
    return RecipeSchema.parse(recipe);
  } catch (error) {
    console.error("[RecipeGenerator] Error generating surprise recipe:", error);
    throw error;
  }
}

/**
 * Internal function: Generate surprise recipe via AI
 * Optimized prompt: 35 tokens vs 98 tokens
 */
async function generateSurpriseRecipeAI(ingredients: string[]): Promise<Recipe> {
  const ingredientsList = ingredients.join(", ");
  const prompt = `Best recipe with: ${ingredientsList}. JSON only.`;

  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "Chef AI. Best recipe as JSON: {title, prepTime (15-60), difficulty (Fácil/Medio/Difícil), calories, hasIngredients, missingIngredients, instructions, description}",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      maxTokens: 800, // Reduced from 1000
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from AI");
    }

    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const recipe = JSON.parse(contentStr);
    return RecipeSchema.parse(recipe);
  } catch (error) {
    console.error("[RecipeGenerator] Error generating surprise recipe:", error);
    throw error;
  }
}
