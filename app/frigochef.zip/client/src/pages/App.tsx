import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ChefHat, Plus, Sparkles, LogOut, Settings, Camera, Trash2, Heart } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { RecipeGenerator } from "@/components/RecipeGenerator";
import { FridgeScan } from "@/components/FridgeScan";
import { WeeklyMenuGenerator } from "@/components/WeeklyMenuGenerator";
import { ExpiryTracker } from "@/components/ExpiryTracker";

interface Ingredient {
  id: string;
  name: string;
  emoji: string;
}

const COMMON_INGREDIENTS = [
  { name: "Huevos", emoji: "🥚" },
  { name: "Queso", emoji: "🧀" },
  { name: "Tomate", emoji: "🍅" },
  { name: "Cebolla", emoji: "🧅" },
  { name: "Pollo", emoji: "🍗" },
  { name: "Arroz", emoji: "🍚" },
  { name: "Pasta", emoji: "🍝" },
  { name: "Lechuga", emoji: "🥬" },
  { name: "Zanahoria", emoji: "🥕" },
  { name: "Patata", emoji: "🥔" },
  { name: "Ajo", emoji: "🧄" },
  { name: "Leche", emoji: "🥛" },
  { name: "Pan", emoji: "🍞" },
  { name: "Jamón", emoji: "🍖" },
  { name: "Pescado", emoji: "🐟" },
  { name: "Champiñones", emoji: "🍄" },
  { name: "Pepino", emoji: "🥒" },
  { name: "Pimiento", emoji: "🫑" },
  { name: "Calabacín", emoji: "🥒" },
  { name: "Brócoli", emoji: "🥦" },
];

export default function AppPage() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [searchInput, setSearchInput] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showRecipeGenerator, setShowRecipeGenerator] = useState(false);
  const [isSurpriseMode, setIsSurpriseMode] = useState(false);
  const [showFridgeScan, setShowFridgeScan] = useState(false);
  const [showWeeklyMenu, setShowWeeklyMenu] = useState(false);
  const [showExpiryTracker, setShowExpiryTracker] = useState(false);

  const { data: commonIngredientsData } = trpc.ingredients.getCommon.useQuery();
  const { data: subscription } = trpc.subscription.get.useQuery();

  const commonIngredients = commonIngredientsData?.map((ing: any) => ({
    name: ing.name,
    emoji: ing.emoji,
  })) || COMMON_INGREDIENTS;

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const filteredSuggestions = commonIngredients.filter(
    (ing: any) =>
      ing.name.toLowerCase().includes(searchInput.toLowerCase()) &&
      !ingredients.some((selected) => selected.name === ing.name)
  );

  const addIngredient = (name: string, emoji: string) => {
    setIngredients([...ingredients, { id: Math.random().toString(), name, emoji }]);
    setSearchInput("");
    setShowSuggestions(false);
  };

  const removeIngredient = (id: string) => {
    setIngredients(ingredients.filter((ing) => ing.id !== id));
  };

  const handleGenerateRecipes = () => {
    if (ingredients.length === 0) {
      alert("Por favor, añade al menos un ingrediente");
      return;
    }
    setIsSurpriseMode(false);
    setShowRecipeGenerator(true);
  };

  const handleSurpriseMe = () => {
    if (ingredients.length === 0) {
      alert("Por favor, añade al menos un ingrediente");
      return;
    }
    setIsSurpriseMode(true);
    setShowRecipeGenerator(true);
  };

  const handleIngredientsFromScan = (scannedIngredients: string[]) => {
    const newIngredients = scannedIngredients
      .filter(name => !ingredients.some(ing => ing.name === name))
      .map(name => ({
        id: Math.random().toString(),
        name,
        emoji: COMMON_INGREDIENTS.find(ing => ing.name === name)?.emoji || "🥘",
      }));
    
    setIngredients([...ingredients, ...newIngredients]);
    setShowFridgeScan(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white sticky top-0 z-50 shadow-sm">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChefHat className="w-8 h-8 text-orange-600" />
            <span className="text-2xl font-bold text-slate-900">FrigoChef</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm text-slate-600">Bienvenido</p>
              <p className="font-semibold text-slate-900">{user?.name || "Usuario"}</p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation("/saved-recipes")}
                title="Mis recetas guardadas"
                className="relative"
              >
                <Heart className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" title="Configuración">
                <Settings className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                title="Cerrar sesión"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-6xl mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Title */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-3">
              ¿Qué tienes hoy en la nevera?
            </h1>
            <p className="text-lg text-slate-600">
              Añade los ingredientes disponibles y descubre recetas deliciosas
            </p>
          </div>

          {/* Ingredient Input Card */}
          <Card className="p-8 mb-8 shadow-lg border-0">
            <div className="space-y-6">
              {/* Search Input */}
              <div className="relative">
                <Input
                  placeholder="Busca un ingrediente..."
                  value={searchInput}
                  onChange={(e) => {
                    setSearchInput(e.target.value);
                    setShowSuggestions(true);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                  className="text-lg py-6 border-2 border-slate-200 focus:border-orange-600 focus:ring-orange-600"
                />

                {/* Suggestions Dropdown */}
                {showSuggestions && filteredSuggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-lg shadow-xl z-10 max-h-64 overflow-y-auto">
                    {filteredSuggestions.map((ing: any) => (
                      <button
                        key={ing.name}
                        onClick={() => addIngredient(ing.name, ing.emoji)}
                        className="w-full text-left px-4 py-3 hover:bg-orange-50 flex items-center gap-3 border-b border-slate-100 last:border-b-0 transition-colors"
                      >
                        <span className="text-2xl">{ing.emoji}</span>
                        <span className="text-slate-900 font-medium">{ing.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Selected Ingredients */}
              {ingredients.length > 0 && (
                <div className="space-y-3">
                  <p className="text-sm font-semibold text-slate-600">
                    Ingredientes seleccionados ({ingredients.length})
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {ingredients.map((ing) => (
                      <div
                        key={ing.id}
                        className="flex items-center justify-between bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-lg px-4 py-3 hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <span className="text-2xl flex-shrink-0">{ing.emoji}</span>
                          <span className="text-slate-900 font-medium truncate">{ing.name}</span>
                        </div>
                        <button
                          onClick={() => removeIngredient(ing.id)}
                          className="text-slate-400 hover:text-red-600 ml-2 flex-shrink-0 transition-colors"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Empty State */}
              {ingredients.length === 0 && (
                <div className="text-center py-12 text-slate-500">
                  <p className="text-lg font-medium">Aún no hay ingredientes</p>
                  <p className="text-sm">Empieza a añadir ingredientes arriba o escanea tu nevera</p>
                </div>
              )}
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="space-y-4">
            {ingredients.length > 0 && (
              <div className="flex gap-4 flex-col sm:flex-row">
                <Button
                  className="flex-1 bg-orange-600 hover:bg-orange-700 text-white text-lg py-6 shadow-lg hover:shadow-xl transition-all"
                  onClick={handleGenerateRecipes}
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Generar recetas
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-lg py-6 border-2 border-orange-600 text-orange-600 hover:bg-orange-50 transition-all"
                  onClick={handleSurpriseMe}
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Sorpréndeme
                </Button>
              </div>
            )}

            {/* Premium Buttons */}
            {subscription?.plan === "premium" && (
              <div className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full text-lg py-6 border-2 border-green-600 text-green-600 hover:bg-green-50 transition-all"
                  onClick={() => setShowFridgeScan(true)}
                >
                  <Camera className="w-5 h-5 mr-2" />
                  Escanear nevera por foto
                </Button>
                <Button
                  variant="outline"
                  className="w-full text-lg py-6 border-2 border-purple-600 text-purple-600 hover:bg-purple-50 transition-all"
                  onClick={() => setShowWeeklyMenu(true)}
                >
                  📅 Menú semanal automático
                </Button>
                <Button
                  variant="outline"
                  className="w-full text-lg py-6 border-2 border-red-600 text-red-600 hover:bg-red-50 transition-all"
                  onClick={() => setShowExpiryTracker(true)}
                >
                  ⏰ Control de caducidad
                </Button>
              </div>
            )}
          </div>

          {/* Info Cards */}
          <div className="mt-12 grid md:grid-cols-2 gap-6">
            <Card className="p-6 bg-blue-50 border-blue-200 hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-blue-900 mb-2">💡 Consejo</h3>
              <p className="text-sm text-blue-800">
                Cuantos más ingredientes añadas, más opciones de recetas tendrás disponibles.
              </p>
            </Card>

            <Card className="p-6 bg-green-50 border-green-200 hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-green-900 mb-2">🎯 Plan Gratuito</h3>
              <p className="text-sm text-green-800">
                Puedes generar 5 recetas hoy. Mañana se reinicia el contador.
              </p>
            </Card>
          </div>
        </div>
      </main>

      {/* Recipe Generator Modal */}
      {showRecipeGenerator && (
        <RecipeGenerator
          ingredients={ingredients.map((ing) => ing.name)}
          isSurpriseMode={isSurpriseMode}
          onRecipeGenerated={() => setShowRecipeGenerator(false)}
        />
      )}

      {/* Fridge Scan Modal */}
      <FridgeScan
        open={showFridgeScan}
        onClose={() => setShowFridgeScan(false)}
        onIngredientsDetected={handleIngredientsFromScan}
      />

      {/* Weekly Menu Modal */}
      <WeeklyMenuGenerator
        open={showWeeklyMenu}
        onClose={() => setShowWeeklyMenu(false)}
      />

      {/* Expiry Tracker Modal */}
      <ExpiryTracker
        open={showExpiryTracker}
        onClose={() => setShowExpiryTracker(false)}
      />
    </div>
  );
}
