import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Heart, ChefHat, Clock, Flame, Trash2, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function SavedRecipes() {
  const [, setLocation] = useLocation();
  const [selectedRecipe, setSelectedRecipe] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { data: subscription } = trpc.subscription.get.useQuery();
  const { data: savedRecipes, refetch, isLoading: isLoadingRecipes } = trpc.recipes.getSaved.useQuery();

  const maxFavorites = subscription?.plan === "premium" ? Infinity : 10;
  const currentCount = savedRecipes?.length || 0;

  const { mutate: deleteRecipeMutation, isPending: isDeleting } = trpc.recipes.delete.useMutation({
    onSuccess: () => {
      toast.success("Receta eliminada de favoritas");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleDeleteRecipe = (recipeId: number) => {
    deleteRecipeMutation({ recipeId });
  };

  if (isLoadingRecipes) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-orange-600 mx-auto mb-4" />
          <p className="text-slate-600">Cargando tus recetas guardadas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/app")}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                <Heart className="w-6 h-6 text-red-500 fill-red-500" />
                Mis Recetas Guardadas
              </h1>
              <p className="text-sm text-slate-600">
                {currentCount} de {maxFavorites === Infinity ? "∞" : maxFavorites} recetas
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {!savedRecipes || savedRecipes.length === 0 ? (
          <Card className="p-12 text-center border-2 border-dashed border-slate-300">
            <ChefHat className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">No tienes recetas guardadas</h2>
            <p className="text-slate-600 mb-6">
              Genera recetas y guarda tus favoritas para acceder a ellas en cualquier momento.
            </p>
            <Button
              onClick={() => setLocation("/app")}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              Volver a generar recetas
            </Button>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedRecipes.map((recipe: any) => (
              <Card
                key={recipe.id}
                className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedRecipe(recipe)}
              >
                <div className="p-6">
                  <h3 className="font-bold text-lg text-slate-900 mb-3 line-clamp-2">
                    {recipe.title}
                  </h3>

                  <div className="space-y-2 mb-4">
                    {recipe.prepTime && (
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Clock className="w-4 h-4" />
                        <span>{recipe.prepTime} min</span>
                      </div>
                    )}
                    {recipe.difficulty && (
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <span className="font-semibold">Dificultad:</span>
                        <span>{recipe.difficulty}</span>
                      </div>
                    )}
                    {recipe.calories && (
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Flame className="w-4 h-4" />
                        <span>{recipe.calories} kcal</span>
                      </div>
                    )}
                  </div>

                  {recipe.description && (
                    <p className="text-sm text-slate-600 mb-4 line-clamp-2">{recipe.description}</p>
                  )}

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedRecipe(recipe);
                      }}
                    >
                      Ver detalles
                    </Button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteRecipe(recipe.id);
                      }}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Recipe Detail Modal */}
      {selectedRecipe && (
        <Dialog open={!!selectedRecipe} onOpenChange={() => setSelectedRecipe(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedRecipe.title}</DialogTitle>
            </DialogHeader>

            <div className="space-y-6">
              {/* Info */}
              <div className="grid grid-cols-3 gap-4">
                {selectedRecipe.prepTime && (
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <Clock className="w-5 h-5 text-orange-600 mx-auto mb-1" />
                    <p className="text-sm font-semibold text-slate-900">{selectedRecipe.prepTime} min</p>
                    <p className="text-xs text-slate-600">Tiempo</p>
                  </div>
                )}
                {selectedRecipe.difficulty && (
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <p className="text-sm font-semibold text-slate-900">{selectedRecipe.difficulty}</p>
                    <p className="text-xs text-slate-600">Dificultad</p>
                  </div>
                )}
                {selectedRecipe.calories && (
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <Flame className="w-5 h-5 text-red-600 mx-auto mb-1" />
                    <p className="text-sm font-semibold text-slate-900">{selectedRecipe.calories}</p>
                    <p className="text-xs text-slate-600">kcal</p>
                  </div>
                )}
              </div>

              {/* Description */}
              {selectedRecipe.description && (
                <div>
                  <h3 className="font-semibold text-slate-900 mb-2">Descripción</h3>
                  <p className="text-slate-600">{selectedRecipe.description}</p>
                </div>
              )}

              {/* Ingredients */}
              {selectedRecipe.ingredients && selectedRecipe.ingredients.length > 0 && (
                <div>
                  <h3 className="font-semibold text-slate-900 mb-3">Ingredientes</h3>
                  <div className="space-y-2">
                    {selectedRecipe.ingredients.map((ingredient: any, idx: number) => (
                      <div key={idx} className="flex items-start gap-2">
                        <span className="text-orange-600 font-bold mt-1">•</span>
                        <span className="text-slate-700">{ingredient}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Instructions */}
              {selectedRecipe.instructions && (
                <div>
                  <h3 className="font-semibold text-slate-900 mb-3">Instrucciones</h3>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <p className="text-slate-700 whitespace-pre-wrap">{selectedRecipe.instructions}</p>
                  </div>
                </div>
              )}

              {/* Nutrition Info */}
              {selectedRecipe.nutritionInfo && (
                <div>
                  <h3 className="font-semibold text-slate-900 mb-3">Información Nutricional</h3>
                  <div className="bg-blue-50 p-4 rounded-lg text-sm text-slate-700">
                    <p>{selectedRecipe.nutritionInfo}</p>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setSelectedRecipe(null)}
                  className="flex-1"
                >
                  Cerrar
                </Button>
                <Button
                  onClick={() => {
                    handleDeleteRecipe(selectedRecipe.id);
                    setSelectedRecipe(null);
                  }}
                  variant="destructive"
                  className="flex-1"
                >
                  Eliminar de favoritas
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
