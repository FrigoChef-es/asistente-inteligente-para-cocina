import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChefHat, Clock, Leaf, Zap, ArrowRight, CheckCircle } from "lucide-react";
import { startLogin } from "@/const";

export default function Home() {
  const { isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50">
      {/* Navigation */}
      <nav className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChefHat className="w-8 h-8 text-orange-600" />
            <span className="text-2xl font-bold text-slate-900">FrigoChef</span>
          </div>
          <Button
            onClick={() => startLogin()}
            className="bg-orange-600 hover:bg-orange-700 text-white"
          >
            Iniciar sesión
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container max-w-6xl mx-auto px-4 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-slate-900 leading-tight">
                La IA que decide qué cocinar por ti y evita que tires comida
              </h1>
              <p className="text-xl text-slate-600">
                Transforma lo que tienes en la nevera en recetas deliciosas. Ahorra tiempo, dinero y reduce el desperdicio.
              </p>
            </div>

            <Button
              onClick={() => startLogin()}
              size="lg"
              className="bg-orange-600 hover:bg-orange-700 text-white text-lg py-7 px-8 w-full md:w-auto"
            >
              Comienza gratis
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>

            {/* Benefits */}
            <div className="space-y-3 pt-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-slate-700">5 recetas gratis cada día</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-slate-700">Sin tarjeta de crédito requerida</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-slate-700">Acceso inmediato a todas las funciones básicas</span>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="hidden md:flex justify-center">
            <div className="relative w-full max-w-sm">
              {/* Decorative circles */}
              <div className="absolute inset-0 bg-gradient-to-br from-orange-200 to-green-200 rounded-3xl blur-3xl opacity-30"></div>
              
              {/* Main card */}
              <Card className="relative p-8 bg-white shadow-2xl">
                <div className="space-y-6">
                  <div className="text-6xl">🥚</div>
                  <h3 className="text-2xl font-bold text-slate-900">¿Qué tienes hoy?</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                      <span className="text-2xl">🥚</span>
                      <span className="text-slate-700">Huevos</span>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                      <span className="text-2xl">🧀</span>
                      <span className="text-slate-700">Queso</span>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                      <span className="text-2xl">🍅</span>
                      <span className="text-slate-700">Tomate</span>
                    </div>
                  </div>
                  <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                    Generar recetas
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              Cómo funciona FrigoChef
            </h2>
            <p className="text-xl text-slate-600">
              Tres pasos simples para descubrir recetas increíbles
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">1</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                Añade ingredientes
              </h3>
              <p className="text-slate-600">
                Selecciona los ingredientes que tienes en tu nevera. Puedes usar el autocompletado o escanear una foto.
              </p>
            </Card>

            {/* Step 2 */}
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">2</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                La IA genera recetas
              </h3>
              <p className="text-slate-600">
                Nuestra IA crea recetas deliciosas y personalizadas basadas en tus ingredientes disponibles.
              </p>
            </Card>

            {/* Step 3 */}
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">3</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                Cocina y disfruta
              </h3>
              <p className="text-slate-600">
                Sigue los pasos de la receta y prepara una comida deliciosa sin desperdiciar comida.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-r from-orange-50 to-green-50">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Benefit 1 */}
            <div className="space-y-4">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">⏱️ Ahorra tiempo</h3>
              <p className="text-slate-600">
                No pierdas más tiempo pensando qué cocinar. La IA decide por ti en segundos.
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="space-y-4">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                <Leaf className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">💰 Ahorra dinero</h3>
              <p className="text-slate-600">
                Aprovecha lo que ya tienes. Reduce compras innecesarias y el desperdicio de comida.
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="space-y-4">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                <Zap className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">🥗 Come mejor</h3>
              <p className="text-slate-600">
                Recetas equilibradas y personalizadas según tus preferencias dietéticas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              Planes simples y transparentes
            </h2>
            <p className="text-xl text-slate-600">
              Elige el plan que mejor se adapte a ti
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {/* Free Plan */}
            <Card className="p-8 border-2 border-slate-200">
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Gratuito</h3>
              <p className="text-slate-600 mb-6">Perfecto para empezar</p>
              <div className="text-4xl font-bold text-slate-900 mb-6">
                €0<span className="text-lg text-slate-600">/mes</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">5 recetas por día</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">10 recetas favoritas</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Autocompletado de ingredientes</span>
                </li>
              </ul>
              <Button
                variant="outline"
                onClick={() => startLogin()}
                className="w-full"
              >
                Comenzar ahora
              </Button>
            </Card>

            {/* Premium Plan */}
            <Card className="p-8 border-2 border-orange-600 bg-gradient-to-br from-orange-50 to-white relative">
              <div className="absolute top-4 right-4 bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                Popular
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Premium</h3>
              <p className="text-slate-600 mb-6">Todo lo que necesitas</p>
              <div className="text-4xl font-bold text-slate-900 mb-6">
                €4,99<span className="text-lg text-slate-600">/mes</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Recetas ilimitadas</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Escaneo de nevera por foto</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Menú semanal automático</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Control de caducidad</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-slate-700">Información nutricional</span>
                </li>
              </ul>
              <Button
                onClick={() => startLogin()}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                Prueba Premium gratis
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-orange-600 to-orange-700 py-20 text-white">
        <div className="container max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">
            ¿Listo para cocinar mejor?
          </h2>
          <p className="text-xl mb-8 text-orange-100">
            Únete a miles de usuarios que ya están ahorrando tiempo y dinero
          </p>
          <Button
            onClick={() => startLogin()}
            size="lg"
            className="bg-white text-orange-600 hover:bg-orange-50 text-lg py-7 px-8"
          >
            Comenzar gratis
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8">
        <div className="container max-w-6xl mx-auto px-4 text-center">
          <p>&copy; 2026 FrigoChef. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
