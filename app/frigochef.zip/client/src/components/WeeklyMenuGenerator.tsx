import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Download } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface WeeklyMenuGeneratorProps {
  open: boolean;
  onClose: () => void;
}

const DIETARY_OPTIONS = [
  "Vegetariano",
  "Vegano",
  "Sin gluten",
  "Bajo en grasas",
  "Alto en proteínas",
];

const RESTRICTION_OPTIONS = [
  "Pescado",
  "Marisco",
  "Frutos secos",
  "Lácteos",
  "Huevos",
  "Soja",
];

export function WeeklyMenuGenerator({ open, onClose }: WeeklyMenuGeneratorProps) {
  const [people, setPeople] = useState("4");
  const [budget, setBudget] = useState("60");
  const [selectedDietary, setSelectedDietary] = useState<string[]>([]);
  const [selectedRestrictions, setSelectedRestrictions] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedMenu, setGeneratedMenu] = useState<any>(null);

  const { data: subscription } = trpc.subscription.get.useQuery();

  const { mutate: generateMenu } = trpc.weeklyMenu.generate.useMutation({
    onSuccess: (data: any) => {
      setGeneratedMenu(data);
      setIsGenerating(false);
      toast.success("Menú semanal generado exitosamente");
    },
    onError: (error: any) => {
      toast.error(error.message || "Error al generar el menú");
      setIsGenerating(false);
    },
  });

  const isPremium = subscription?.plan === "premium";

  if (!isPremium) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Menú Semanal - Plan Premium</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-slate-600">
              El menú semanal automático es una función exclusiva del plan Premium.
            </p>
            <p className="text-sm text-slate-500">
              Actualiza tu plan para desbloquear esta y otras funciones premium.
            </p>
            <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
              Actualizar a Premium
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const handleGenerate = () => {
    if (!people || !budget) {
      toast.error("Por favor, completa todos los campos");
      return;
    }

    setIsGenerating(true);
    generateMenu({
      people: parseInt(people),
      budget: parseFloat(budget),
      dietaryPreferences: selectedDietary,
      restrictions: selectedRestrictions,
    });
  };

  const toggleDietary = (option: string) => {
    setSelectedDietary((prev) =>
      prev.includes(option) ? prev.filter((o) => o !== option) : [...prev, option]
    );
  };

  const toggleRestriction = (option: string) => {
    setSelectedRestrictions((prev) =>
      prev.includes(option) ? prev.filter((o) => o !== option) : [...prev, option]
    );
  };

  const downloadShoppingList = () => {
    if (!generatedMenu) return;

    const csv = [
      ["Ingrediente", "Cantidad", "Categoría", "Costo estimado"],
      ...generatedMenu.shoppingList.map((item: any) => [
        item.name,
        item.quantity,
        item.category,
        `€${item.estimatedCost.toFixed(2)}`,
      ]),
      [],
      ["Costo total estimado", `€${generatedMenu.totalEstimatedCost.toFixed(2)}`],
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "lista-compra.csv";
    a.click();
  };

  if (generatedMenu) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Tu Menú Semanal</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Menu */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg text-slate-900">Menú Semanal</h3>
              <div className="grid gap-4">
                {generatedMenu.menu.map((day: any, idx: number) => (
                  <Card key={idx} className="p-4">
                    <h4 className="font-bold text-orange-600 mb-3">{day.day}</h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-xs text-slate-600 font-semibold">DESAYUNO</p>
                        <p className="text-slate-900">{day.breakfast}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-600 font-semibold">COMIDA</p>
                        <p className="text-slate-900">{day.lunch}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-600 font-semibold">CENA</p>
                        <p className="text-slate-900">{day.dinner}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Shopping List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg text-slate-900">Lista de Compra</h3>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={downloadShoppingList}
                  className="gap-2"
                >
                  <Download className="w-4 h-4" />
                  Descargar CSV
                </Button>
              </div>

              <div className="max-h-64 overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-slate-100">
                    <tr>
                      <th className="text-left px-3 py-2">Ingrediente</th>
                      <th className="text-left px-3 py-2">Cantidad</th>
                      <th className="text-left px-3 py-2">Categoría</th>
                      <th className="text-right px-3 py-2">Costo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {generatedMenu.shoppingList.map((item: any, idx: number) => (
                      <tr key={idx} className="border-b border-slate-200 hover:bg-slate-50">
                        <td className="px-3 py-2">{item.name}</td>
                        <td className="px-3 py-2">{item.quantity}</td>
                        <td className="px-3 py-2">
                          <span className="text-xs bg-slate-100 px-2 py-1 rounded">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right">€{item.estimatedCost.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <Card className="p-4 bg-green-50 border-green-200">
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-green-900">Costo total estimado:</span>
                  <span className="text-2xl font-bold text-green-600">
                    €{generatedMenu.totalEstimatedCost.toFixed(2)}
                  </span>
                </div>
              </Card>
            </div>

            {/* Notes */}
            {generatedMenu.notes && (
              <Card className="p-4 bg-blue-50 border-blue-200">
                <p className="text-sm text-blue-900">{generatedMenu.notes}</p>
              </Card>
            )}

            {/* Actions */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setGeneratedMenu(null)}
                className="flex-1"
              >
                Generar otro
              </Button>
              <Button onClick={onClose} className="flex-1 bg-orange-600 hover:bg-orange-700 text-white">
                Cerrar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Generar Menú Semanal</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="people">Número de personas</Label>
              <Input
                id="people"
                type="number"
                min="1"
                max="20"
                value={people}
                onChange={(e) => setPeople(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budget">Presupuesto (€)</Label>
              <Input
                id="budget"
                type="number"
                min="10"
                max="500"
                step="5"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
              />
            </div>
          </div>

          {/* Dietary Preferences */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Preferencias dietéticas</Label>
            <div className="space-y-2">
              {DIETARY_OPTIONS.map((option) => (
                <div key={option} className="flex items-center gap-2">
                  <Checkbox
                    id={`dietary-${option}`}
                    checked={selectedDietary.includes(option)}
                    onCheckedChange={() => toggleDietary(option)}
                  />
                  <label
                    htmlFor={`dietary-${option}`}
                    className="text-sm cursor-pointer text-slate-700"
                  >
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Restrictions */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Restricciones alimentarias</Label>
            <div className="space-y-2">
              {RESTRICTION_OPTIONS.map((option) => (
                <div key={option} className="flex items-center gap-2">
                  <Checkbox
                    id={`restriction-${option}`}
                    checked={selectedRestrictions.includes(option)}
                    onCheckedChange={() => toggleRestriction(option)}
                  />
                  <label
                    htmlFor={`restriction-${option}`}
                    className="text-sm cursor-pointer text-slate-700"
                  >
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generando...
                </>
              ) : (
                "Generar menú"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
