import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Heart, ChefHat, Clock, Flame, AlertCircle, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface Recipe {
  title: string;
  prepTime: number;
  difficulty: "Fácil" | "Medio" | "Difícil";
  calories: number;
  hasIngredients: string[];
  missingIngredients: string[];
  instructions: string;
  description?: string;
}

interface RecipeGeneratorProps {
  ingredients: string[];
  isSurpriseMode?: boolean;
  onRecipeGenerated?: (recipe: Recipe) => void;
}

export function RecipeGenerator({ ingredients, isSurpriseMode = false, onRecipeGenerated }: RecipeGeneratorProps) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [currentRecipeIndex, setCurrentRecipeIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [showRecipe, setShowRecipe] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { data: subscription } = trpc.subscription.get.useQuery();
  const { mutate: generateRecipesMutation } = trpc.recipeGeneration.generate.useMutation({
    onSuccess: (data) => {
      setRecipes(data as Recipe[]);
      setCurrentRecipeIndex(0);
      setIsLoading(false);
      if (data.length > 0 && onRecipeGenerated) {
        onRecipeGenerated(data[0] as Recipe);
      }
    },
    onError: (error) => {
      setError(error.message);
      setIsLoading(false);
    },
  });

  const { mutate: surpriseRecipeMutation } = trpc.recipeGeneration.surprise.useMutation({
    onSuccess: (data) => {
      setRecipes([data as Recipe]);
      setCurrentRecipeIndex(0);
      setIsLoading(false);
      if (onRecipeGenerated) {
        onRecipeGenerated(data as Recipe);
      }
    },
    onError: (error) => {
      setError(error.message);
      setIsLoading(false);
    },
  });

  const { mutate: saveRecipe } = trpc.recipes.save.useMutation({
    onSuccess: () => {
      toast.success("Receta guardada en favoritas");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const currentRecipe = recipes[currentRecipeIndex];
  const isPremium = subscription?.plan === "premium";

  // Auto-generate recipes on mount
  if (recipes.length === 0 && !isLoading && !error) {
    setIsLoading(true);
    if (isSurpriseMode) {
      surpriseRecipeMutation({ ingredients });
    } else {
      generateRecipesMutation({ ingredients, count: 2 });
    }
  }

  const handleNextRecipe = () => {
    if (currentRecipeIndex < recipes.length - 1) {
      setCurrentRecipeIndex(currentRecipeIndex + 1);
    }
  };

  const handlePreviousRecipe = () => {
    if (currentRecipeIndex > 0) {
      setCurrentRecipeIndex(currentRecipeIndex - 1);
    }
  };

  const handleSaveRecipe = () => {
    if (currentRecipe) {
      saveRecipe({
        title: currentRecipe.title,
        description: currentRecipe.description,
        ingredients: currentRecipe.hasIngredients,
        instructions: currentRecipe.instructions,
        prepTime: currentRecipe.prepTime,
        difficulty: currentRecipe.difficulty,
        calories: currentRecipe.calories,
        sourceIngredients: ingredients,
      });
    }
  };

  return (
    <Dialog open={showRecipe} onOpenChange={setShowRecipe}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-12 space-y-4">
            <Loader2 className="w-8 h-8 animate-spin text-orange-600" />
            <p className="text-slate-600">Generando recetas deliciosas...</p>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg">
            <p className="font-semibold mb-2">Error al generar recetas</p>
            <p className="text-sm">{error}</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => {
                setError(null);
                setShowRecipe(false);
              }}
            >
              Cerrar
            </Button>
          </div>
        )}

        {currentRecipe && !isLoading && (
          <div className="space-y-6">
            <DialogHeader>
              <DialogTitle className="text-2xl">{currentRecipe.title}</DialogTitle>
            </DialogHeader>

            {/* Recipe Info */}
            <div className="grid grid-cols-3 gap-4">
              <Card className="p-4 text-center">
                <Clock className="w-5 h-5 mx-auto mb-2 text-orange-600" />
                <p className="text-sm text-slate-600">Tiempo</p>
                <p className="font-semibold">{currentRecipe.prepTime} min</p>
              </Card>
              <Card className="p-4 text-center">
                <ChefHat className="w-5 h-5 mx-auto mb-2 text-orange-600" />
                <p className="text-sm text-slate-600">Dificultad</p>
                <p className="font-semibold">{currentRecipe.difficulty}</p>
              </Card>
              <Card className="p-4 text-center">
                <Flame className="w-5 h-5 mx-auto mb-2 text-orange-600" />
                <p className="text-sm text-slate-600">Calorías</p>
                <p className="font-semibold">{currentRecipe.calories}</p>
              </Card>
            </div>

            {/* Ingredients */}
            <div className="space-y-3">
              <h3 className="font-semibold text-lg">Ingredientes que tienes</h3>
              <div className="space-y-2">
                {currentRecipe.hasIngredients.map((ing, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-green-700 bg-green-50 p-2 rounded">
                    <span>✓</span>
                    <span>{ing}</span>
                  </div>
                ))}
              </div>
            </div>

            {currentRecipe.missingIngredients.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                  Te falta
                </h3>
                <div className="space-y-2">
                  {currentRecipe.missingIngredients.map((ing, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-slate-600 bg-slate-50 p-2 rounded">
                      <span>○</span>
                      <span>{ing}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Instructions */}
            <div className="space-y-3">
              <h3 className="font-semibold text-lg">Preparación</h3>
              <div className="bg-slate-50 p-4 rounded-lg whitespace-pre-wrap text-sm text-slate-700">
                {currentRecipe.instructions}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex gap-3 pt-4 border-t">
              <Button
                variant="outline"
                onClick={handlePreviousRecipe}
                disabled={currentRecipeIndex === 0 || recipes.length === 1}
                className="flex-1"
              >
                ← Anterior
              </Button>
              <Button
                onClick={handleSaveRecipe}
                className="flex-1 bg-orange-600 hover:bg-orange-700"
              >
                <Heart className="w-4 h-4 mr-2" />
                Guardar
              </Button>
              <Button
                variant="outline"
                onClick={handleNextRecipe}
                disabled={currentRecipeIndex === recipes.length - 1 || recipes.length === 1}
                className="flex-1"
              >
                Siguiente →
              </Button>
            </div>

            {recipes.length > 1 && (
              <p className="text-center text-sm text-slate-500">
                Receta {currentRecipeIndex + 1} de {recipes.length}
              </p>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
