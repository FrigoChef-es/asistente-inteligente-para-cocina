import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Upload, Loader2, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface FridgeScanProps {
  open: boolean;
  onClose: () => void;
  onIngredientsDetected: (ingredients: string[]) => void;
}

export function FridgeScan({ open, onClose, onIngredientsDetected }: FridgeScanProps) {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [detectedIngredients, setDetectedIngredients] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: subscription } = trpc.subscription.get.useQuery();
  const { mutate: analyzeImage } = trpc.fridgeScan.analyze.useMutation({
    onSuccess: (data: any) => {
      setDetectedIngredients(data.ingredients);
      setIsAnalyzing(false);
    },
    onError: (error: any) => {
      setError(error.message);
      setIsAnalyzing(false);
    },
  });

  const isPremium = subscription?.plan === "premium";

  if (!isPremium) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Escaneo de Nevera - Plan Premium</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-slate-600">
              El escaneo de nevera por foto es una función exclusiva del plan Premium.
            </p>
            <p className="text-sm text-slate-500">
              Actualiza tu plan para desbloquear esta y otras funciones premium.
            </p>
            <Button className="w-full bg-orange-600 hover:bg-orange-700">
              Actualizar a Premium
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setError("Por favor, selecciona una imagen válida");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError("La imagen debe ser menor a 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setImagePreview(result);
      setError(null);
      setDetectedIngredients([]);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!imagePreview) {
      setError("Por favor, selecciona una imagen");
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    // Convert base64 to blob and upload
    try {
      analyzeImage({ imageBase64: imagePreview });
    } catch (err) {
      setError("Error al analizar la imagen");
      setIsAnalyzing(false);
    }
  };

  const handleUseIngredients = () => {
    onIngredientsDetected(detectedIngredients);
    onClose();
  };

  const toggleIngredient = (ingredient: string) => {
    setDetectedIngredients((prev) =>
      prev.includes(ingredient)
        ? prev.filter((i) => i !== ingredient)
        : [...prev, ingredient]
    );
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>📸 Escanea tu nevera</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {!imagePreview && (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center cursor-pointer hover:border-orange-400 transition"
            >
              <Upload className="w-8 h-8 mx-auto mb-3 text-slate-400" />
              <p className="font-semibold text-slate-900 mb-1">Sube una foto de tu nevera</p>
              <p className="text-sm text-slate-600">o arrastra la imagen aquí</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          )}

          {imagePreview && (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setDetectedIngredients([]);
                  }}
                  className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {isAnalyzing && (
                <div className="flex items-center justify-center py-8 space-x-3">
                  <Loader2 className="w-5 h-5 animate-spin text-orange-600" />
                  <p className="text-slate-600">Analizando imagen...</p>
                </div>
              )}

              {detectedIngredients.length > 0 && !isAnalyzing && (
                <div className="space-y-3">
                  <p className="font-semibold text-slate-900">Ingredientes detectados:</p>
                  <div className="grid grid-cols-2 gap-2">
                    {detectedIngredients.map((ingredient) => (
                      <button
                        key={ingredient}
                        onClick={() => toggleIngredient(ingredient)}
                        className="text-left p-3 bg-orange-50 border border-orange-200 rounded-lg hover:bg-orange-100 transition"
                      >
                        <input
                          type="checkbox"
                          checked={true}
                          onChange={() => {}}
                          className="mr-2"
                        />
                        {ingredient}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setImagePreview(null)}
                  className="flex-1"
                >
                  Cambiar imagen
                </Button>
                {!detectedIngredients.length && !isAnalyzing && (
                  <Button
                    onClick={handleAnalyze}
                    className="flex-1 bg-orange-600 hover:bg-orange-700"
                  >
                    Analizar
                  </Button>
                )}
                {detectedIngredients.length > 0 && (
                  <Button
                    onClick={handleUseIngredients}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    Usar ingredientes
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
