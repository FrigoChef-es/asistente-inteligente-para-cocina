import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, Plus, Trash2, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ExpiryTrackerProps {
  open: boolean;
  onClose: () => void;
}

export function ExpiryTracker({ open, onClose }: ExpiryTrackerProps) {
  const [productName, setProductName] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [quantity, setQuantity] = useState("");
  const [category, setCategory] = useState("Otros");
  const [isAdding, setIsAdding] = useState(false);

  const { data: subscription } = trpc.subscription.get.useQuery();
  const { data: expiryItems, refetch } = trpc.expiry.getItems.useQuery();
  const { mutate: addItem } = trpc.expiry.addItem.useMutation({
    onSuccess: () => {
      toast.success("Producto añadido");
      setProductName("");
      setExpiryDate("");
      setQuantity("");
      setCategory("Otros");
      setIsAdding(false);
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || "Error al añadir producto");
      setIsAdding(false);
    },
  });

  const isPremium = subscription?.plan === "premium";

  if (!isPremium) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Control de Caducidad - Plan Premium</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-slate-600">
              El control de caducidad es una función exclusiva del plan Premium.
            </p>
            <p className="text-sm text-slate-500">
              Actualiza tu plan para desbloquear esta y otras funciones premium.
            </p>
            <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
              Actualizar a Premium
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const handleAddItem = () => {
    if (!productName || !expiryDate) {
      toast.error("Por favor, completa los campos requeridos");
      return;
    }

    setIsAdding(true);
    addItem({
      productName,
      expiryDate,
      quantity,
      category,
    });
  };

  const getExpiryStatus = (expiryDate: string) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysLeft = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (daysLeft < 0) return { status: "expired", label: "Caducado", color: "red" };
    if (daysLeft <= 2) return { status: "urgent", label: `${daysLeft}d`, color: "red" };
    if (daysLeft <= 7) return { status: "warning", label: `${daysLeft}d`, color: "amber" };
    return { status: "ok", label: `${daysLeft}d`, color: "green" };
  };

  const sortedItems = (expiryItems || []).sort((a: any, b: any) => {
    const aStatus = getExpiryStatus(a.expiryDate).status;
    const bStatus = getExpiryStatus(b.expiryDate).status;
    const statusOrder = { expired: 0, urgent: 1, warning: 2, ok: 3 };
    return statusOrder[aStatus as keyof typeof statusOrder] - statusOrder[bStatus as keyof typeof statusOrder];
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Control de Caducidad</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Add Item Form */}
          <Card className="p-4 bg-orange-50 border-orange-200">
            <h3 className="font-semibold text-slate-900 mb-4">Añadir producto</h3>
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product">Producto *</Label>
                  <Input
                    id="product"
                    placeholder="Ej: Leche, Yogur..."
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expiry">Fecha de caducidad *</Label>
                  <Input
                    id="expiry"
                    type="date"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Cantidad</Label>
                  <Input
                    id="quantity"
                    placeholder="Ej: 1L, 500g..."
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Categoría</Label>
                  <select
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  >
                    <option>Lácteos</option>
                    <option>Carnes</option>
                    <option>Frutas</option>
                    <option>Verduras</option>
                    <option>Congelados</option>
                    <option>Otros</option>
                  </select>
                </div>
              </div>

              <Button
                onClick={handleAddItem}
                disabled={isAdding}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              >
                {isAdding ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Añadiendo...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Añadir producto
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Items List */}
          <div className="space-y-3">
            <h3 className="font-semibold text-slate-900">Productos registrados</h3>

            {sortedItems.length === 0 ? (
              <Card className="p-8 text-center text-slate-500">
                <p>No hay productos registrados</p>
                <p className="text-sm">Añade productos para recibir alertas de caducidad</p>
              </Card>
            ) : (
              <div className="space-y-2">
                {sortedItems.map((item: any, idx: number) => {
                  const status = getExpiryStatus(item.expiryDate);
                  const colorClasses = {
                    red: "bg-red-50 border-red-200",
                    amber: "bg-amber-50 border-amber-200",
                    green: "bg-green-50 border-green-200",
                  };

                  return (
                    <Card
                      key={idx}
                      className={`p-4 border-2 ${colorClasses[status.color as keyof typeof colorClasses]}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            {status.status !== "ok" && (
                              <AlertCircle className={`w-4 h-4 text-${status.color}-600`} />
                            )}
                            <h4 className="font-semibold text-slate-900">{item.productName}</h4>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-slate-600">
                            {item.quantity && <span>{item.quantity}</span>}
                            <span className="text-xs bg-slate-100 px-2 py-1 rounded">
                              {item.category}
                            </span>
                            <span>Caduca: {new Date(item.expiryDate).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 ml-4">
                          <span
                            className={`font-bold text-${status.color}-600 text-lg min-w-[3rem] text-right`}
                          >
                            {status.label}
                          </span>
                          <button className="text-slate-400 hover:text-red-600 transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>

          {/* Info */}
          <Card className="p-4 bg-blue-50 border-blue-200">
            <p className="text-sm text-blue-900">
              💡 <strong>Consejo:</strong> Recibe sugerencias automáticas de recetas cuando algo está
              próximo a caducar. Así evitas desperdiciar comida.
            </p>
          </Card>

          <Button onClick={onClose} className="w-full bg-slate-200 hover:bg-slate-300 text-slate-900">
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
